# SetUp Project Environment

# Install Python 3.6

    $ wget https://www.python.org/ftp/python/3.6.0/Python-3.6.0.tar.xz
    $ tar xJf Python-3.6.0.tar.xz
    $ cd Python-3.6.0
    $ ./configure
    $ make
    $ make install

# Install Virtual Environment Dependency

    $ pip install virtualenv

# Create virtual environment

    $ virtualenv boco


# Activate the virtual environment:

    $ bash
    $ source boco/bin/activate

# Install the project's requirements

    $ pip install -r requirements.txt

# Transform models so that we could deploy on a database

    $ python manage.py makemigrations


# Synchronizes the database with the current set of models and migrations

    $ python manage.py migrate


# Start the server
    $ python manage.py runserver 0.0.0.0:8000

    Now, services should be up and running at the following host and port.

    $ http://localhost:8000

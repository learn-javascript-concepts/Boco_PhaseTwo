from django.db import transaction
from rest_framework import serializers

from .models import Customer, SubContractor, WorkOrder
from .utils import get_location_from_address


class WorkOrderSerializer(serializers.ModelSerializer):
    """
    Serializer class to create and list workorders
    """
    class Meta:
        model = WorkOrder
        fields = (
            'id',
            'work_order_num',
            'customer_po_num',
            'work_order_by',
            'date_of_order',
            'date_work_started',
            'status',
            'created',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'status': {'read_only': True},

        }


class RetreiveUpdateWorkOrderSerializer(serializers.ModelSerializer):
    """
    Serializer class to handle update retrieve of a workorder
    """

    customer_details = serializers.SerializerMethodField(read_only=True)
    sub_contrator_details = serializers.SerializerMethodField(read_only=True)

    def get_customer_details(self, workorder):
        if workorder.customer is not None:
            return RetreiveUpdateCustomerSerializer(workorder.customer).data
        return None

    def get_sub_contrator_details(self, workorder):
        if workorder.sub_contractor is not None:
            return RetreiveUpdateSubContractorSerializer(workorder.sub_contractor).data
        return None

    class Meta:
        model = WorkOrder
        fields = (
            'id',
            'work_order_num',
            'customer_po_num',
            'work_order_by',
            'description',
            'other_requirements',
            'customer',
            'sub_contractor',
            'has_additional_comments',
            'comments',
            'status',
            'created',
            'customer_details',
            'sub_contrator_details',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'work_order_num': {'read_only': True},
            'customer_po_num': {'read_only': True},
            'work_order_by': {'read_only': True},
            'status': {'read_only': True},

        }


class CustomerSerializer(serializers.ModelSerializer):
    """
    Serializer class to create and list customers
    """
    latitude = None
    longitude = None

    class Meta:
        model = Customer
        fields = (
            'id',
            'email',
            'contact_number',
            'poc',
            'company_name',
            'address',
            'address_latitude',
            'address_longitude',
            'created',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'address_latitude': {'read_only': True},
            'address_longitude': {'read_only': True},

        }

    def validate_address(self, address):
        location = get_location_from_address(address)
        self.longitude = location.get('lng')
        self.latitude = location.get('lat')
        return address

    def create(self, validated_data):
        with transaction.atomic():
            validated_data['address_latitude'] = self.latitude
            validated_data['address_longitude'] = self.longitude
            instance = super().create(validated_data)
            return instance


class RetreiveUpdateCustomerSerializer(serializers.ModelSerializer):
    """
    Serializer class to get and update a particular customer object.
    """
    class Meta:
        model = Customer
        fields = (
            'id',
            'email',
            'company_name',
            'contact_number',
            'poc',
            'address',
            'address_latitude',
            'address_longitude',
            'created',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'address_latitude': {'read_only': True},
            'address_longitude': {'read_only': True},

        }


class SubContractorSerializer(serializers.ModelSerializer):
    """
    Serializer class to create and list subcontractor objects
    """
    latitude = None
    longitude = None

    class Meta:
        model = SubContractor
        fields = (
            'id',
            'email',
            'contact_number',
            'poc',
            'sub_contractor_name',
            'address',
            'address_latitude',
            'address_longitude',
            'created',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'address_latitude': {'read_only': True},
            'address_longitude': {'read_only': True},

        }

    def validate_address(self, address):
        location = get_location_from_address(address)
        self.longitude = location.get('lng')
        self.latitude = location.get('lat')
        return address

    def create(self, validated_data):
        with transaction.atomic():
            validated_data['address_latitude'] = self.latitude
            validated_data['address_longitude'] = self.longitude
            instance = super().create(validated_data)
            return instance


class RetreiveUpdateSubContractorSerializer(serializers.ModelSerializer):
    """
    Serializer class to handle update retrieve of a Subcontractor
    """

    class Meta:
        model = SubContractor
        fields = (
            'id',
            'email',
            'sub_contractor_name',
            'contact_number',
            'poc',
            'address',
            'address_latitude',
            'address_longitude',
            'created',
        )
        extra_kwargs = {
            'id': {'read_only': True},
            'created': {'read_only': True},
            'address_latitude': {'read_only': True},
            'address_longitude': {'read_only': True},

        }

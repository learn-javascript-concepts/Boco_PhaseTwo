from core.exceptions import BaseValidationError


class AddressCannotBeLocatedError(BaseValidationError):
    """An exception class that extends BaseValidationError. This exception is raised when address
        entered cannot be processed for latitude and longitude
             This class overrides both 'message' and 'code' variables.
        """
    message = 'Address cannot be located.'
    code = 'address_not_located'

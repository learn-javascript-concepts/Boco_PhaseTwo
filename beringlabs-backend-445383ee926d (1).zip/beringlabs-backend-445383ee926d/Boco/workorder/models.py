from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models

from core.models import BaseModel


class SubContractor(BaseModel):
    """
    Model class for Sub Contractor
    """
    id = models.AutoField(primary_key=True, editable=False)
    sub_contractor_name = models.CharField(max_length=100)
    email = models.EmailField()
    contact_number = models.PositiveIntegerField()
    poc = models.CharField(max_length=50)
    address = models.CharField(max_length=200)
    address_latitude = models.DecimalField(decimal_places=8, max_digits=12)
    address_longitude = models.DecimalField(decimal_places=8, max_digits=12)


class Customer(BaseModel):
    """
    Model class for Customer
    """
    id = models.AutoField(primary_key=True, editable=False)
    company_name = models.CharField(max_length=100)
    email = models.EmailField()
    contact_number = models.PositiveIntegerField()
    poc = models.CharField(max_length=50)
    address = models.CharField(max_length=200)
    address_latitude = models.DecimalField(decimal_places=8, max_digits=12)
    address_longitude = models.DecimalField(decimal_places=8, max_digits=12)


class Supplier(BaseModel):
    """
    Model class for Supplier
    """
    id = models.AutoField(primary_key=True, editable=False)
    company_name = models.CharField(max_length=100)
    ticket_number = models.IntegerField()
    cost = models.DecimalField(decimal_places=2, max_digits=10)


class WorkOrder(BaseModel):
    """
    Model class for workorder
    """
    id = models.AutoField(primary_key=True, editable=False)
    STATUS_CREATED = 'CREATED'
    STATUS_STARTED = 'STARTED'
    STATUS_IN_PROGRESS = 'IN_PROGRESS'
    STATUS_COMPLETED = 'COMPLETED'

    STATUS_CHOICES = (
        (STATUS_CREATED, 'Created'),
        (STATUS_STARTED, 'Started'),
        (STATUS_IN_PROGRESS, 'In Progress'),
        (STATUS_COMPLETED, 'Completed'),
    )

    status = models.CharField(choices=STATUS_CHOICES, max_length=100, default=STATUS_CREATED)
    work_order_num = models.PositiveIntegerField(validators=[
            MaxValueValidator(100000),
            MinValueValidator(1000),
        ]
    )
    customer_po_num = models.PositiveIntegerField()
    work_order_by = models.CharField(max_length=100)
    date_of_order = models.DateTimeField(null=True, blank=True)
    date_work_started = models.DateTimeField(null=True, blank=True)
    description = models.CharField(max_length=500, null=True, blank=True)
    other_requirements = models.CharField(max_length=500, null=True, blank=True)
    customer = models.ForeignKey(
        Customer,
        related_name='customers',
        on_delete=models.DO_NOTHING,
        null=True,
        blank=True,
    )
    sub_contractor = models.ForeignKey(
        SubContractor,
        related_name='sub_contractors',
        on_delete=models.DO_NOTHING,
        null=True,
        blank=True,
    )
    has_additional_comments = models.BooleanField(default=False)
    comments = models.CharField(
        max_length=500,
        null=True,
        blank=True,
    )

    class Meta:
        unique_together = ('work_order_num', 'customer_po_num', 'work_order_by')

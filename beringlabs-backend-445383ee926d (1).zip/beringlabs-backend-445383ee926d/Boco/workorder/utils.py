import requests
from django.conf import settings

from . import exceptions as ex


def get_location_from_address(address):
    url = 'https://maps.googleapis.com/maps/api/geocode/json'
    params = {'sensor': 'false', 'address': address, 'key': settings.GOOGLE_MAP_API_KEY}
    response = requests.get(url, params=params)
    results = response.json()['results']
    location = results[0]['geometry']['location']
    if len(location) == 0:
        raise ex.AddressCannotBeLocatedError()
    return location

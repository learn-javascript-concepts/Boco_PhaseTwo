# # import jwt
# # from rest_framework_jwt.settings import api_settings
# #
# # from accounts.config import app_config as accounts_config
# # from accounts.exceptions import UserDoesNotExistError
# # from accounts.models import User
# #
# # jwt_decode_handler = api_settings.JWT_DECODE_HANDLER
# #
# #
# # class RemoteJSONWebTokenMixin(object):
# #     """
# #     Mixin that set serializer class based on `remote token` field
# #
# #     Returns a serializer class.
# #     """
# #
# #     def get_serializer_class(self):
# #         """
# #         Return the class to use for the serializer.
# #         Defaults to using `self.serializer_class`.
# #         """
# #         has_jwt_token = accounts_config.jwt_token in self.request.data
# #         has_remote_token = accounts_config.remote_token in self.request.data
# #
# #         if has_remote_token:
# #             self.serializer_class = self.remote_token_serializer_class
# #         elif has_jwt_token:
# #             try:
# #                 jwt_token = self.request.data.get(accounts_config.jwt_token)
# #                 payload = jwt_decode_handler(jwt_token)
# #                 if payload and payload.get(accounts_config.remote_token):
# #                     self.serializer_class = self.remote_token_serializer_class
# #             except(jwt.ExpiredSignature, jwt.DecodeError):
# #                 pass
# #             except User.DoesNotExist:
# #                 raise UserDoesNotExistError()
# #             except Exception:
# #                 pass
# #         return self.serializer_class
#
#
# class ActionSerializerMixin(object):
#
#     action_serializers = {}
#
#     def get_serializer_class(self):
#         if self.action in self.action_serializers:
#             self.serializer_class = self.action_serializers[self.action]
#         return super().get_serializer_class()

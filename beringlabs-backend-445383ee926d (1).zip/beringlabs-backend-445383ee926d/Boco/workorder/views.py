from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets
from rest_framework.response import Response
from sequences import get_next_value

from . import serializers as workorder_serializers
from .models import Customer, SubContractor, WorkOrder


class WorkOrderViewSet(viewsets.ModelViewSet):
    """
    Viewset to handle requests to create a workorder object or get list of objects.
    """
    model = WorkOrder
    queryset = WorkOrder.objects.all()

    filter_backends = (DjangoFilterBackend,)

    # specify the fields on which filter support is required.
    filter_fields = ('work_order_by', 'work_order_num', 'customer_po_num',)

    action_serializers = {
        'create': workorder_serializers.WorkOrderSerializer,
        'list': workorder_serializers.WorkOrderSerializer,
    }
    serializer_class = workorder_serializers.WorkOrderSerializer


class RetreiveUpdateWorkOrderViewSet(viewsets.ModelViewSet):
    """
    Viewset to handle following requests
        1. Retrieve a workorder object
        2. Update a workorder detail
    """
    model = WorkOrder
    serializer_class = workorder_serializers.RetreiveUpdateWorkOrderSerializer

    action_serializers = {
        'retrieve': workorder_serializers.RetreiveUpdateWorkOrderSerializer,
        'put': workorder_serializers.RetreiveUpdateWorkOrderSerializer,
    }

    def get_queryset(self):
        """
        Return active records
        :return queryset:
        """
        queryset = self.model.objects.all()
        return self.apply_queryset_filters(queryset)

    def apply_queryset_filters(self, queryset):
        return queryset


class CustomerViewSet(viewsets.ModelViewSet):
    """
       Viewset to handle requests to create a customer object or get list of objects.
    """
    model = Customer
    queryset = Customer.objects.all()
    filter_backends = (DjangoFilterBackend,)

    # specify the fields on which filter support is required.
    filter_fields = ('company_name',)

    action_serializers = {
        'create': workorder_serializers.CustomerSerializer,
        'list': workorder_serializers.CustomerSerializer,
    }
    serializer_class = workorder_serializers.CustomerSerializer


class RetreiveUpdateCustomerViewSet(viewsets.ModelViewSet):
    """
    Viewset to handle following requests
        1. Retrieve a customer object
        2. Update a customer detail
    """

    model = Customer
    serializer_class = workorder_serializers.RetreiveUpdateCustomerSerializer

    action_serializers = {
        'retrieve': workorder_serializers.RetreiveUpdateCustomerSerializer,
        'put': workorder_serializers.RetreiveUpdateCustomerSerializer,
    }

    def get_queryset(self):
        """
        Return active records
        :return queryset:
        """
        queryset = self.model.objects.all()
        return self.apply_queryset_filters(queryset)

    def apply_queryset_filters(self, queryset):
        return queryset


class SubContractorViewSet(viewsets.ModelViewSet):
    """
       Viewset to handle requests to create a subcontractor object or get list of objects.
    """
    model = SubContractor
    queryset = SubContractor.objects.all()
    filter_backends = (DjangoFilterBackend,)

    # specify the fields on which filter support is required.
    filter_fields = ('sub_contractor_name')

    action_serializers = {
        'create': workorder_serializers.SubContractorSerializer,
        'list': workorder_serializers.SubContractorSerializer,
    }
    serializer_class = workorder_serializers.SubContractorSerializer


class RetreiveUpdateSubContractorViewSet(viewsets.ModelViewSet):
    """
    Viewset to handle following requests
        1. Retrieve a subcontractor object
        2. Update a subcontractor detail
    """

    model = SubContractor
    serializer_class = workorder_serializers.RetreiveUpdateSubContractorSerializer

    action_serializers = {
        'retrieve': workorder_serializers.RetreiveUpdateSubContractorSerializer,
        'put': workorder_serializers.RetreiveUpdateSubContractorSerializer,
    }

    def get_queryset(self):
        """
        Return active records
        :return queryset:
        """
        queryset = self.model.objects.all()
        return self.apply_queryset_filters(queryset)

    def apply_queryset_filters(self, queryset):
        return queryset


class GetNextWorkOrderNumberViewSet(viewsets.ViewSet):

    def retrieve(self, request, pk=None):
        next_workorder = {
            'work_order_number': get_next_value('WorkOrder', initial_value=1000)
        }

        return Response(next_workorder)

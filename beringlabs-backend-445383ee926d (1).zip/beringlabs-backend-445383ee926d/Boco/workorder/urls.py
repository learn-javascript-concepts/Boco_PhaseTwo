from django.conf.urls import url

from . import views

list_create_workorder = views.WorkOrderViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })

workorder_detail_update = views.RetreiveUpdateWorkOrderViewSet.as_view({
    'get': 'retrieve',
    'put': 'partial_update',
})

list_create_customer = views.CustomerViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })

customer_detail_update = views.RetreiveUpdateCustomerViewSet.as_view({
    'get': 'retrieve',
    'put': 'partial_update',
})

list_create_subcontractor = views.SubContractorViewSet.as_view({
        'get': 'list',
        'post': 'create',
    })

subcontractor_detail_update = views.RetreiveUpdateSubContractorViewSet.as_view({
    'get': 'retrieve',
    'put': 'partial_update',
})

workorder_number_sequence = views.GetNextWorkOrderNumberViewSet.as_view({
    'get': 'retrieve',
})


urlpatterns = [
    url(r'^workorders/$', list_create_workorder),
    url(r'^workorders/(?P<pk>[a-z0-9-]+)/$', workorder_detail_update),
    url(r'^workorders/getNextNumber/$', workorder_number_sequence),
    url(r'^customers/$', list_create_customer),
    url(r'^customers/(?P<pk>[a-z0-9-]+)/$', customer_detail_update),
    url(r'^subcontractors/$', list_create_subcontractor),
    url(r'^subcontractor/(?P<pk>[a-z0-9-]+)/$', subcontractor_detail_update),

]
